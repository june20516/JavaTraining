package mydate;

public class FinalInit {
	private static final  int YEAR;
	static {
		// 비추천코드 단지 static block 에서 
		//static final 멤버변수의 값을 처리문장에 의해서 초기화 시키는 방법을 보여주는 예
		FinalInit finalInit = new FinalInit(2000);
		YEAR=finalInit.year;
		System.out.println(YEAR);
	}
	public final int year;
	public FinalInit() {
		year=1;
	}
	public FinalInit(int year) {
		this.year = year;
	}
	public int get(int field) {
		return (YEAR==field)? year : 0;
	}
	public static void main(String[] args) {
		int year=FinalInit.YEAR;
		System.out.println(year);
	}
}
