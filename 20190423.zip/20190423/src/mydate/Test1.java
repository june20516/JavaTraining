package mydate;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long l = System.currentTimeMillis();
		System.out.println(l);
		
		Date date = new Date(l);
		System.out.println(date);
		
		System.out.println(GregorianCalendar.YEAR);
		
		GregorianCalendar gc = new  GregorianCalendar();
		System.out.println(gc.get(GregorianCalendar.YEAR) );

		GregorianCalendar gc2 = new  GregorianCalendar(2007,11,11);
		System.out.println(gc2.get(GregorianCalendar.YEAR) );
		//  ???  왜 final 하다면서 값이 바뀌는지?????
		
		//음력 양력   ==>  
		/*기원 연수가 4로 나누어 떨어지는 해는 우선 윤년으로 하고,
		 *  ② 그 중에서 100으로 나누어 떨어지는 해는 평년으로 하며, 
		 *  ③ 다만 400으로 나누어 떨어지는 해는 다시 윤년으로 정하였다.
		 *   이로써 1년의 평균길이를 365.2425일로 정하여 역에 썼으므로 실제의 1년보다 0.0003일이 길다.
		[네이버 지식백과] 윤년 [leap year, 閏年] (두산백과)*/
		
		int year = 1900;//
		if(year%4==0 &&   year%100!=0 ||  year%400==0) {
			System.out.println("윤년");
		}else 
			System.out.println("평년");
		
		GregorianCalendar gs2 = new GregorianCalendar(2000, 1, 1);
		System.out.println( gs2.isLeapYear(year)? "윤년" : "평년" );
		System.out.println(gs2.YEAR+" "+gs2.get(Calendar.YEAR) );
		System.out.println( gs2.isLeapYear(gs2.YEAR)? "윤년" : "평년" );
	}
}




