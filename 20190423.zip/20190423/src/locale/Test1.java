package locale;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Formatter;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Locale locale = new Locale("Japanese","Japan");
		System.out.println(locale);
		
		
		
		
		Locale locale2 = Locale.getDefault();
		System.out.println(locale2);
		System.out.println(locale2.getDisplayCountry() );
		
		GregorianCalendar g = new GregorianCalendar(locale);
		System.out.println(g);
		
		TimeZone  timeZone = TimeZone.getDefault(); 
		System.out.println(timeZone);		
		
		
		// 오늘의 날짜를 이용 2019.04.23 사용하는 타임존과 나라를 출력
		
		SimpleDateFormat dateFormat =
				new SimpleDateFormat("yyyy.MM.dd");
		String todayStr= dateFormat.format(new Date());
		System.out.println(todayStr);
		//  나머지는 과제 
		// Formatter formatter;
	}

}




