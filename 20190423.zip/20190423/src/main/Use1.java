package main;

import enumtest.SampleEnum;
public class Use1 {
	public static void main(String[] args) {
		SampleEnum  enum1 =SampleEnum.AAA;
		SampleEnum[] enums = SampleEnum.values();
		for(SampleEnum se : enums) {
			System.out.println(se+":"+se.getLabel());
		}
	}
}
