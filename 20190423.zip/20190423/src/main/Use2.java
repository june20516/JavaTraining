package main;

import java.lang.reflect.Method;
import java.util.Date;

import enumtest.Sex;

public class Use2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Class class1= Sex.class;
		 System.out.println(class1.getName());
		 System.out.println(Sex.class.getName());
		 
		 Method[] methods=   class1.getMethods();
		 for(Method method : methods) {
			 System.out.println(method);
		 }
		 
		 System.out.println( class1.isAnonymousClass() );
		 System.out.println( class1.isLocalClass());
		 System.out.println( class1.isEnum() );
		 System.out.println( class1.getTypeName() );
		 
		 try {
			Date today=   (Date)Class.forName("java.util.Date").newInstance();
			System.out.println(today);
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
