package swing;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JTextField;
import java.awt.GridBagConstraints;
import javax.swing.JButton;
import java.awt.Insets;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Test4 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextArea textArea;
	private JButton btn7;
	private JButton btn9;
	private JButton btn8;
	private ActionListener  actionListener = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			String btnText = ((JButton)e.getSource()).getText();
			String tfValue=  textField.getText();
			textField.setText(tfValue+btnText);
		}
	};
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Test4 frame = new Test4();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Test4() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 204, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 1.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		textField = new JTextField();
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.gridwidth = 4;
		gbc_textField.insets = new Insets(0, 0, 5, 0);
		gbc_textField.fill = GridBagConstraints.BOTH;
		gbc_textField.gridx = 0;
		gbc_textField.gridy = 0;
		contentPane.add(textField, gbc_textField);
		textField.setColumns(10);
		
		JButton btnCopy = new JButton("CopyRun");
		btnCopy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.setText( textField.getText());
				textField.setText("");
			}
		});
		
		btn7 = new JButton("7");
		btn7.addActionListener( actionListener );
		/*
		 * gbc_btnNewButton.insets = new Insets(0, 0, 5, 5); gbc_btnNewButton.gridx = 1;
		 * gbc_btnNewButton.gridy = 1;
		 */
		contentPane.add(btn7, 
				setGridBagConstraints(1, 1, GridBagConstraints.BOTH, 1, 1));
		
		btn8 = new JButton("8");
		btn8.addActionListener(actionListener);
		/*
		 * GridBagConstraints gbc_btnNewButton_2 = new GridBagConstraints();
		 * gbc_btnNewButton_2.insets = new Insets(0, 0, 5, 5); gbc_btnNewButton_2.gridx
		 * = 2; gbc_btnNewButton_2.gridy = 1;
		 */
		contentPane.add(btn8, setGridBagConstraints(1,1,1,2,1));
		
		btn9 = new JButton("9");
		btn9.addActionListener(actionListener);
		contentPane.add(btn9, setGridBagConstraints(1,1,1,3,1));
		/*
		 * GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		 * gbc_btnNewButton.insets = new Insets(0, 0, 5, 5); gbc_btnNewButton.gridx = 1;
		 * gbc_btnNewButton.gridy = 2;
		 */
		contentPane.add(btnCopy, setGridBagConstraints(1, 1, GridBagConstraints.BOTH, 1, 2));
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				textArea.setText("");
				textField.setText("");
			}
		});
		/*
		 * GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		 * gbc_btnNewButton_1.insets = new Insets(0, 0, 5, 0); gbc_btnNewButton_1.gridx
		 * = 3; gbc_btnNewButton_1.gridy = 2;
		 */
		contentPane.add(btnClear, 
				setGridBagConstraints(1, 1, GridBagConstraints.BOTH, 3, 2));
		
		textArea = new JTextArea();
		contentPane.add(textArea, setGridBagConstraints(1,2,GridBagConstraints.BOTH,0,3));
		
	}
    private GridBagConstraints  setGridBagConstraints
    	(int gridheight, int   gridwidth,int fill , int gridx  , int gridy     ) {
    	GridBagConstraints constraints = new GridBagConstraints();
    	constraints.insets = new Insets(0, 0, 0, 5);
    	constraints.gridheight=gridheight;
    	constraints.gridwidth=gridwidth;
    	constraints.fill=fill;
    	constraints.gridx=gridx;
    	constraints.gridy=gridy;
    	return constraints;
    }
}












