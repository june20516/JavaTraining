package enumtest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Main {
	public static void main(String[] args) throws IOException {
		Sex[] genders = Sex.values();
		for(Sex gender : genders) {
			System.out.println(gender);
		}

		//BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		InputStream br= System.in;
		System.out.println("남자 : M | 여자 : F");
		char genderInput = (char) br.read();
		//System.out.println(('m'-genderInput)+" "  + ('M'-genderInput));
		System.out.println(Sex.search(genderInput));
	}
}