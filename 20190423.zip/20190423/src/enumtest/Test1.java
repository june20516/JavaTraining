package enumtest;

final class WeekDayConstants{
	public static final String[] weekdayStrs = 
		{"SUNDAY","MONDAY","TUESDAY",
				"WEDNESDAY","THURSDAY","FRIDAY","SATURDAY"};
	static public  final int SUNDAY=1;
	static public  final int SATURDAY=7;
	
	static public  final int MONDAY=2;
	static public  final int TUESDAY=3;
	static public  final int WEDNESDAY=4;
	static public  final int THURSDAY=5;
	static public  final int FRIDAY=6;
}
enum WeekDay{
	SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY
}

public class Test1 {
	public static String getJob(WeekDay weekDay) {
		if(weekDay == WeekDay.SATURDAY || 
				weekDay == WeekDay.SUNDAY ) {
			return "쉬는 날";
		}
		return "3D 작업";
	}
	public static String getJob(int dayInWeek) {
		if(dayInWeek == WeekDayConstants.SATURDAY ||
				dayInWeek == WeekDayConstants.SUNDAY) {
			return "쉬는 날";
		}
		return "3D 작업";
	}
	
	public static void main(String[] args) {
		String str2 = getJob(WeekDay.SUNDAY);
		System.out.println(WeekDay.SUNDAY+str2);
		
		String str= getJob(WeekDayConstants.SUNDAY);
		System.out.println(
				WeekDayConstants.weekdayStrs[
				     WeekDayConstants.SUNDAY-1]
				 + str);

		WeekDay day = WeekDay.MONDAY;
		String  str3;
		switch (day) {
		case WEDNESDAY:str3 ="야근 없는 가족과 함께 날";
			break;
		case SATURDAY:
		case SUNDAY : str3 ="쉬는 날"; 
			break;
		default:  str3 ="3D 작업하는 날";
			break;
		}
		System.out.println( day + str3 );
		
		WeekDay[] days=  WeekDay.values();
		System.out.println(days.length);
		for( WeekDay day2 : days ) {
			//day2.
			System.out.println(day2);
		}
		
		
	}
	
}





