package enumtest;

public enum SampleEnum {
   AAA("A","최우수등급"),BBB("B","우수등급");
	private String code;
	private String label;
	
	/*
	 * static public SampleEnum[] values() { return null; }
	 */
	
	
	private SampleEnum(String code,String label) {
		this.code = code;
		this.label = label;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	
}
