package enumtest;

public enum Sex {
	남자('M',"Male","Man"),여자('F',"Female","Woman");
	
	private char code;
	private String name;
	private String engWord;	//갯수제한이 없는듯?
	
	public char getCode() {
		return code;
	}

	public static String search(char code) {
		//Sex[] genders = values();  대소문자 상관없이 처리가 되도록 
		for (Sex gender : values()) {
			switch (code - gender.getCode()) {
			case 0:
			case 32:return gender.getName();
			}
		}
		return null;
	}
	
	public static char search(String name) {
		//Sex[] genders = Sex.values();
		for (Sex gender : values()) {
			if (gender.getName().equalsIgnoreCase(name))
				return gender.code;
		}
		return '\u0000';
	}

	public void setCode(char code) {
		this.code = code;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEngWord() {
		return engWord;
	}


	public void setEngWord(String engWord) {
		this.engWord = engWord;
	}


	private Sex(char code, String name, String engWord) {
		this.code = code;
		this.name = name;
		this.engWord = engWord;
	}
	
	
}