package middle;

public class Exam {

}
